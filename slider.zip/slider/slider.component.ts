import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slider',
  imports: [CommonModule],
  templateUrl: './slider.component.html',
  styleUrl: './slider.component.css'
})
export class SliderComponent  {
  currentIndex = 0;
  visibleCards = 3; // Number of cards visible at once

  hoveredIndex: number | null = null;
  cards = [
    {
      title: 'Card 1',
      image: 'https://picsum.photos/300/200?random=1',
      description: 'Description for card 1'
    },
    {
      title: 'Card 2',
      image: 'https://picsum.photos/300/200?random=2',
      description: 'Description for card 2'
    },
    {
      title: 'Card 3',
      image: 'https://picsum.photos/300/200?random=3',
      description: 'Description for card 3'
    },
    {
      title: 'Card 4',
      image: 'https://picsum.photos/300/200?random=4',
      description: 'Description for card 4'
    },
    {
      title: 'Card 5',
      image: 'https://picsum.photos/300/200?random=5',
      description: 'Description for card 5'
    }
  ];


  get maxIndex(): number {
    return Math.max(0, this.cards.length - this.visibleCards);
  }

  nextCard(): void { 
    if (this.currentIndex < this.maxIndex) {
      this.currentIndex++;
    } else {
      this.currentIndex = 0; // Loop back to start
    }
  }

  prevCard(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
    } else {
      this.currentIndex = this.maxIndex; // Loop to end
    }
  }
  goToCard(index: number): void {
    if (index >= 0 && index <= this.maxIndex) {
      this.currentIndex = index;
    }
  }
  setHover(index: number | null): void {
    this.hoveredIndex = index;
  }

}
