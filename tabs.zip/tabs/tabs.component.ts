import { Component,Inject, OnDestroy, PLATFORM_ID  } from '@angular/core';
import { CommonModule } from '@angular/common';  // or import { NgFor } from '@angular/common';
import { isPlatformBrowser } from '@angular/common';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';

@Component({
  selector: 'app-tabs',
  imports: [CommonModule],
  standalone: true,
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css'],
  animations: [
    trigger('fadeAnimation', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('500ms ease-in', style({ opacity: 1 }))
      ]),
      transition(':leave', [
        animate('500ms ease-out', style({ opacity: 0 }))
      ])
    ])
  ]})

  export class TabsComponent implements OnDestroy {
    selectedTab = 0;
    tabs = [
      { label: '1', content: 'Content for Tab 1.' },
      { label: '2', content: 'Content for Tab 2.' },
      { label: '3', content: 'Content for Tab 3.' }
    ];
  
    private intervalId?: number;
    private isBrowser: boolean;
  
    constructor(@Inject(PLATFORM_ID) private platformId: Object) {
      this.isBrowser = isPlatformBrowser(this.platformId);
      if (this.isBrowser) {
        this.startAutoSwitch();
      }
    }
  
    selectTab(index: number) {
      this.selectedTab = index;
      if (this.isBrowser) {
        this.restartAutoSwitch();
      }
    }
  
    startAutoSwitch() {
      this.intervalId = window.setInterval(() => {
        this.selectedTab = (this.selectedTab + 1) % this.tabs.length;
      }, 2000);
    }
  
    restartAutoSwitch() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
      }
      this.startAutoSwitch();
    }
  
    ngOnDestroy() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
      }
    }
  }