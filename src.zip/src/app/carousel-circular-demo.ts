import { Component, OnInit } from '@angular/core';
import { ImportsModule } from './imports';
import { Product } from '@/domain/product';
import { ProductService } from '@/service/productservice';
import { Carousel } from 'primeng/carousel';
import { Tag } from 'primeng/tag';
import { MenuItem } from 'primeng/api';
import { Ripple } from 'primeng/ripple';
import { AccordionModule } from 'primeng/accordion';
import { GalleriaModule } from 'primeng/galleria';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';

@Component({
    selector: 'carousel-circular-demo',
    templateUrl: './carousel-circular-demo.html',
    standalone: true,
    imports: [ImportsModule, ButtonModule, InputTextModule],
    providers: [ProductService],
    styles: [`
        .video-container {
            position: relative;
            overflow: hidden;
            border-radius: 6px;
            margin-bottom: 1rem;
        }
        
        ::ng-deep .p-galleria .p-galleria-indicators {
            background: rgba(0,0,0,0.3);
            padding: 0.5rem;
            border-radius: 0 0 6px 6px;
        }
        
        ::ng-deep .p-galleria .p-galleria-indicator button {
            background-color: var(--primary-color);
            width: 1rem;
            height: 1rem;
            border-radius: 50%;
        }

        /* Chatbot styles */
        .chatbot-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            transition: all 0.3s ease;

            .chatbot-button {
                width: 60px;
                height: 60px;
                font-size: 1.5rem;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            }

            .chat-window {
                width: 300px;
                height: 400px;
                background: #D2F0CC;
                border-radius: 10px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
                display: flex;
                flex-direction: column;
                overflow: hidden;
                margin-bottom: 15px;

                .chat-header {
                    background: var(--primary-color);
                    color: white;
                    padding: 15px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }

                .chat-messages {
                    flex: 1;
                    padding: 15px;
                    overflow-y: auto;
                }

                .chat-input {
                    display: flex;
                    padding: 10px;
                    border-top: 1px solid #eee;

                    input {
                        flex: 1;
                        margin-right: 10px;
                    }
                }
            }
        }
    `]
})
export class CarouselCircularDemo implements OnInit {
    products: Product[] | undefined;
    responsiveOptions: any[] | undefined;
    items: MenuItem[] | undefined;
    selectedImage: string | null = null;
    imageMap: {[key: string]: string} = {
        'Nature': 'https://primefaces.org/cdn/primeng/images/galleria/galleria1.jpg',
        'Animals': 'https://primefaces.org/cdn/primeng/images/galleria/galleria2.jpg',
        'Cities': 'https://primefaces.org/cdn/primeng/images/galleria/galleria3.jpg'
      };
    
    // Video/Galleria properties
    mediaItems: any[] = [];
    galleriaResponsiveOptions: any[] = [
        {
            breakpoint: '1024px',
            numVisible: 1
        },
        {
            breakpoint: '768px',
            numVisible: 1
        },
        {
            breakpoint: '560px',
            numVisible: 1
        }
    ];

    // Chatbot properties
    isChatExpanded = false;
    hasNewMessages = false;
    chatMessages: string[] = ['Hello! I am AskVeda, your digital assistant. How can I help you today?'];
    newMessage = '';

    constructor(private productService: ProductService) {}

    ngOnInit() {
        this.productService.getProductsSmall().then((products) => {
            this.products = products;
        });

        this.responsiveOptions = [
            {
                breakpoint: '1400px',
                numVisible: 2,
                numScroll: 1
            },
            {
                breakpoint: '1199px',
                numVisible: 3,
                numScroll: 1
            },
            {
                breakpoint: '767px',
                numVisible: 2,
                numScroll: 1
            },
            {
                breakpoint: '575px',
                numVisible: 1,
                numScroll: 1
            }
        ];

        // Initialize menu items
        this.items = [
            {
                label: 'Home',
                icon: 'pi pi-home',
            },
            {
                label: 'Who we are',
                icon: 'pi pi-search',
                badge: '3',
                items: [
                    {
                        label: 'Core',
                        icon: 'pi pi-bolt',
                        shortcut: '⌘+S',
                    },
                    {
                        label: 'Blocks',
                        icon: 'pi pi-server',
                        shortcut: '⌘+B',
                    },
                    {
                        separator: true,
                    },
                    {
                        label: 'UI Kit',
                        icon: 'pi pi-pencil',
                        shortcut: '⌘+U',
                    },
                ],
            },
            {
                label: 'What we are',
                icon: 'pi pi-search',
                badge: '3',
                items: [
                    {
                        label: 'Core',
                        icon: 'pi pi-bolt',
                        shortcut: '⌘+S',
                    },
                    {
                        label: 'Blocks',
                        icon: 'pi pi-server',
                        shortcut: '⌘+B',
                    },
                    {
                        separator: true,
                    },
                    {
                        label: 'UI Kit',
                        icon: 'pi pi-pencil',
                        shortcut: '⌘+U',
                    },
                ],
            },
            {
                label: 'Projects',
                icon: 'pi pi-search',
                badge: '3',
                items: [
                    {
                        label: 'Core',
                        icon: 'pi pi-bolt',
                        shortcut: '⌘+S',
                    },
                    {
                        label: 'Blocks',
                        icon: 'pi pi-server',
                        shortcut: '⌘+B',
                    },
                    {
                        separator: true,
                    },
                    {
                        label: 'UI Kit',
                        icon: 'pi pi-pencil',
                        shortcut: '⌘+U',
                    },
                ],
            },
        ];

        // Initialize media items for video/gallery
        this.mediaItems = [
            {
                type: 'video',
                source: 'asset\invideo-ai-480 Corporate Life_ The Daily Grind 2025-04-17.mp4'
            },
            {
                type: 'image',
                source: 'assets/images/slide1.jpg'
            },
            {
                type: 'image',
                source: 'assets/images/slide2.jpg'
            }
        ];
    }

    getSeverity(status: string) {
        // switch (status) {
        //     case 'INSTOCK':
        //         return 'success';
        //     case 'LOWSTOCK':
        //         return 'warn';
        //     case 'OUTOFSTOCK':
        //         return 'danger';
        // }
    }

    // Chatbot methods
    toggleChat() {
        this.isChatExpanded = !this.isChatExpanded;
        if (this.isChatExpanded) {
            this.hasNewMessages = false;
        }
    }

    sendMessage() {
        if (this.newMessage.trim()) {
            this.chatMessages.push(`You: ${this.newMessage}`);
            // Here you would typically send to a chat service
            this.newMessage = '';
            
            // Simulate bot response after 1 second
            setTimeout(() => {
                this.chatMessages.push('Askveda: Thanks for your message! Now we are in under construction');
            }, 1000);
        }
    }
    onAccordionOpen(event: any) {
        const header = event.originalEvent.target.innerText.trim();
        this.selectedImage = this.imageMap[header];
      }
    
      onAccordionClose() {
        this.selectedImage = null;
      }
}