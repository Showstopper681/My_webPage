import { Routes } from '@angular/router';
import { UnderConstructionComponent } from './under-construction/under-construction.component';

export const routes: Routes = [
  // ... your existing routes
  { path: 'under-construction', component: UnderConstructionComponent }
];